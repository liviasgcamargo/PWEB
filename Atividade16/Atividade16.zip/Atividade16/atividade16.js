function confirmarCurso() {
    const selectCurso = document.getElementById('cursos');
    const cursoSelecionado = selectCurso.value;

    if (cursoSelecionado) {
      const confirmacao = confirm("Deseja abrir a página do curso selecionado?");
      if (confirmacao) {
        abrirJanela(cursoSelecionado);
      }
    }
  }

  function abrirJanela(curso) {
    let url;
    switch (curso) {
      case 'ads':
        url = 'https://www.fatecsorocaba.edu.br/curso_ads.asp';
        break;
      case 'gestao':
        url = 'https://www.fatecsorocaba.edu.br/curso_ead-ge.asp';
        break;
      case 'logistica':
        url = 'https://www.fatecsorocaba.edu.br/curso_log.asp';
        break;
      default:
        url = 'https://www.fatecsorocaba.edu.br/default.asp';
    }

    window.open(url, '_blank', 'width=600,height=300');
  }