/*var sql =require('mssql');
module.exports = function(){
 
const sqlConfig = {
//sqlConfig = {
  user: '',
  password: '',
  database: 'BD', //Na FATEC, utilizar o database BD ou LP8
  server: 'APOLO',
  driver:'msnodesql8',
  options: {
    encrypt: false, 
    trustServerCertificate: true // se você não tiver um certificado de servidor configurado
  }
}
return sql.connect(config);
}
*/
const sql = require('mssql');
module.exports = function()
{
    const sqlConfig =
    {
        user: '',
        password: '',
        database: 'BD',
        server: 'apolo',
        options:
        {
            encrypt: false,
            trustServerCertificate: true // se você não tiver um certificado de servidor configurado
        }
    }
    return sql.connect(sqlConfig);
}