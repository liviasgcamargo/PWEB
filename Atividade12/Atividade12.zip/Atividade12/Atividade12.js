//Calculando Area do Retangulo

function Retangulo(base, altura) {
    this.base = base;
    this.altura = altura;
    this.calcularArea = function() {
      return this.base * this.altura;
    };
  }
  
  var retangulo = new Retangulo(5, 10);
  alert("Area do retangulo:" + retangulo.calcularArea());

  //Criando Classes
  
  class Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo) {
      this.nomeCorrentista = nomeCorrentista;
      this.banco = banco;
      this.numeroConta = numeroConta;
      this.saldo = saldo;
    }
    
    getNomeCorrentista() {
      return this.nomeCorrentista;
    }
    
    setNomeCorrentista(nome) {
      this.nomeCorrentista = nome;
    }
    
    getBanco() {
      return this.banco;
    }
    
    setBanco(banco) {
      this.banco = banco;
    }
    
    getNumeroConta() {
      return this.numeroConta;
    }
    
    setNumeroConta(numero) {
      this.numeroConta = numero;
    }
    
    getSaldo() {
      return this.saldo;
    }
    
    setSaldo(saldo) {
      this.saldo = saldo;
    }
  }
  
  class Corrente extends Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo, saldoEspecial) {
      super(nomeCorrentista, banco, numeroConta, saldo);
      this.saldoEspecial = saldoEspecial;
    }
    
    getSaldoEspecial() {
      return this.saldoEspecial;
    }
    
    setSaldoEspecial(saldoEspecial) {
      this.saldoEspecial = saldoEspecial;
    }
  }
  
  class Poupanca extends Conta {
    constructor(nomeCorrentista, banco, numeroConta, saldo, juros, dataVencimento) {
      super(nomeCorrentista, banco, numeroConta, saldo);
      this.juros = juros;
      this.dataVencimento = dataVencimento;
    }
    
    getJuros() {
      return this.juros;
    }
    
    setJuros(juros) {
      this.juros = juros;
    }
    
    getDataVencimento() {
      return this.dataVencimento;
    }
    
    setDataVencimento(dataVencimento) {
      this.dataVencimento = dataVencimento;
    }
  }
  
  var contaCorrente = new Corrente();
  contaCorrente.setNomeCorrentista(prompt("Informe o nome do correntista da conta corrente:"));
  contaCorrente.setBanco(prompt("Informe o banco da conta corrente:"));
  contaCorrente.setNumeroConta(prompt("Informe o numero da conta corrente:"));
  contaCorrente.setSaldo(prompt("Informe o saldo da conta corrente:"));
  contaCorrente.setSaldoEspecial(prompt("Informe o saldo especial da conta corrente:"));
  
  var contaPoupanca = new Poupanca();
  contaPoupanca.setNomeCorrentista(prompt("Informe o nome do correntista da conta poupança:"));
  contaPoupanca.setBanco(prompt("Informe o banco da conta poupança:"));
  contaPoupanca.setNumeroConta(prompt("Informe o numero da conta poupança:"));
  contaPoupanca.setSaldo(prompt("Informe o saldo da conta poupança:"));
  contaPoupanca.setJuros(prompt("Informe os juros da conta poupança:"));
  contaPoupanca.setDataVencimento(prompt("Informe a data de vencimento da conta poupança:"));
  
  alert("Dados da Conta Corrente: ");
  alert("Nome do Correntista: " + contaCorrente.getNomeCorrentista());
  alert("Banco: " + contaCorrente.getBanco());
  alert("Número da Conta: " + contaCorrente.getNumeroConta());
  alert("Saldo: " + contaCorrente.getSaldo());
  alert("Saldo Especial: " + contaCorrente.getSaldoEspecial());
  
  alert("\nDados da Conta Poupança: ");
  alert("Nome do Correntista: " + contaPoupanca.getNomeCorrentista());
  alert("Banco: " + contaPoupanca.getBanco());
  alert("Número da Conta: " + contaPoupanca.getNumeroConta());
  alert("Saldo: " + contaPoupanca.getSaldo());
  alert("Juros: " + contaPoupanca.getJuros());
  alert("Data de Vencimento: " + contaPoupanca.getDataVencimento());
  