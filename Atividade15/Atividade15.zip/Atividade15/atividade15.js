function validarFormulario(event) {
    if (document.forms["meuForm"]["nome"].value.length < 10) {
        alert("Nome deve ter pelo menos 10 caracteres.");
        event.preventDefault();
        return false;
    }

    if (document.forms["meuForm"]["email"].value.indexOf("@") == -1 || document.forms["meuForm"]["email"].value.indexOf(".") == -1) {
        alert("Email inválido.");
        event.preventDefault();
        return false;
    }

    if (document.forms["meuForm"]["comentario"].value.length < 20) {
        alert("Comentário deve ter pelo menos 20 caracteres.");
        event.preventDefault();
        return false;
    }

    if (!document.forms["meuForm"]["pesquisa"].value) {
        alert("Por favor, selecione uma opção na pesquisa.");
        event.preventDefault();
        return false;
    }

    var mensagem = (document.forms["meuForm"]["pesquisa"].value === "sim") ? "Volte sempre a esta página!" : "Que bom que você voltou a visitar esta página!";
    alert(mensagem);
}