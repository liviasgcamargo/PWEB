var entrada = document.getElementById("entrada");
var maiuscula = document.getElementById("maiuscula");
var minuscula = document.getElementById("minuscula");

maiuscula.addEventListener('change', function () {
  if (this.checked) {
    entrada.value = entrada.value.toUpperCase();
    minuscula.checked = false;
  }
});

minuscula.addEventListener('change', function () {
  if (this.checked) {
    entrada.value = entrada.value.toLowerCase();
    maiuscula.checked = false;
  }
});