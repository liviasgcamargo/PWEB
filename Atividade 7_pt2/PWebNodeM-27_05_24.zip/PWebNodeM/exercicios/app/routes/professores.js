module.exports = function(app){
    app.get('/informacao/professores',function(req,res){
        res.render("informacao/professores");
        //res.end("<html><body>Professores legais da Fatec Sorocaba</body></html>")
    });
}