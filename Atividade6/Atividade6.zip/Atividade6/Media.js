var nome;
var nt1;
var nt2;
var nt3;

nome = prompt("Qual eh o seu nome?");

nt1 = prompt("Digite a Primeira Nota: ");
nt2 = prompt("Digite a Segunda Nota: ");
nt3 = prompt("Digite a Terceira Nota: ");

nt1 = parseFloat(nt1);
nt2 = parseFloat(nt2);
nt3 = parseFloat(nt3);

var media = (nt1 + nt2 + nt3)/3;

alert("A media das notas eh: " + media);


