var val1;
var val2;
var soma;
var sub;
var mult;
var div;
var resto;

val1 = prompt("Digite o primeiro Numero: ");
val2 = prompt("Digite o segundo Numero: ");

val1 = parseFloat(val1);
val2 = parseFloat(val2);

soma = val1 + val2;
sub = val1 - val2;
mult = val1 * val2;
div = val1 / val2;
resto = val1 % val2;

alert("Soma: " + soma);
alert("Subtracao: " + sub);
alert("Multiplicacao: " + mult);
alert("Divisao: " + div);
alert("Resto: " + resto);

