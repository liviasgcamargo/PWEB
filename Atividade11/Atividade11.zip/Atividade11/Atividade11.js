//Forma 1

var Funcionario1 = {
    Matricula: "001",
    Nome: "João Silva",
    Funcao: "Desenvolvedor"
};
alert("Matricula = " + Funcionario1.Matricula + " Nome = " + Funcionario1.Nome + " Função = " + Funcionario1.Funcao);

//Forma 2

var Funcionario2 = new Object();
Funcionario2.Matricula = "002";
Funcionario2.Nome = "Luíza Gomes";
Funcionario2.Funcao = "Engenheiro";

alert("Matricula = " + Funcionario2.Matricula + " Nome = " + Funcionario2.Nome + " Função = " + Funcionario2.Funcao);

//Forma 3

function Funcionario(Matricula, Nome, Funcao) {
    this.Matricula = Matricula;
    this.Nome = Nome;
    this.Funcao = Funcao;

    this.MostraDados = function () {
        return "Matricula = " + this.Matricula + " Nome = " + this.Nome + " Função = " + this.Funcao;
    }
}
var Funcionario3 = new Funcionario("12345", "Matheus Barros", "Arquiteto");
alert(Funcionario3.MostraDados());
